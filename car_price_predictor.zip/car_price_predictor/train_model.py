from model_utils import MODEL_PATH, train_model, save_model


def main() -> None:
    model, metrics = train_model()
    save_model(model, MODEL_PATH)

    print("Model training completed.")
    print(f"Model saved at: {MODEL_PATH}")
    print(f"Mean Absolute Error: {metrics['mae']:.2f} lakh")
    print(f"Root Mean Squared Error: {metrics['rmse']:.2f} lakh")
    print(f"R-squared Score: {metrics['r2']:.3f}")


if __name__ == "__main__":
    main()
