import csv
import pickle
from dataclasses import dataclass
from pathlib import Path

import numpy as np


BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "data" / "car_data.csv"
MODEL_PATH = BASE_DIR / "models" / "car_price_model.pkl"


NUMERIC_FIELDS = [
    "original_price_lakh",
    "kilometers_driven",
    "owner_count",
    "car_age_years",
]

CATEGORICAL_FIELDS = [
    "company_name",
    "car_model",
    "fuel_type",
    "transmission",
]

TARGET_FIELD = "selling_price_lakh"


@dataclass
class CarPriceModel:
    weights: np.ndarray
    feature_order: list[str]
    category_maps: dict[str, list[str]]
    company_to_models: dict[str, list[str]]


def load_dataset(csv_path: Path = DATA_PATH) -> list[dict]:
    with csv_path.open("r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        rows = []
        for row in reader:
            clean_row = {
                "company_name": row["company_name"].strip(),
                "car_model": row["car_model"].strip(),
                "original_price_lakh": float(row["original_price_lakh"]),
                "kilometers_driven": float(row["kilometers_driven"]),
                "fuel_type": row["fuel_type"].strip(),
                "transmission": row["transmission"].strip(),
                "owner_count": float(row["owner_count"]),
                "car_age_years": float(row["car_age_years"]),
                "selling_price_lakh": float(row["selling_price_lakh"]),
            }
            rows.append(clean_row)
        return rows


def extract_categories(rows: list[dict]) -> dict[str, list[str]]:
    category_maps = {}
    for field in CATEGORICAL_FIELDS:
        category_maps[field] = sorted({row[field] for row in rows})
    return category_maps


def build_company_to_models(rows: list[dict]) -> dict[str, list[str]]:
    company_to_models = {}
    for row in rows:
        company = row["company_name"]
        company_to_models.setdefault(company, set()).add(row["car_model"])
    return {company: sorted(models) for company, models in company_to_models.items()}


def build_feature_order(category_maps: dict[str, list[str]]) -> list[str]:
    feature_order = ["bias"]
    feature_order.extend(NUMERIC_FIELDS)

    for field in CATEGORICAL_FIELDS:
        for category in category_maps[field]:
            feature_order.append(f"{field}={category}")

    return feature_order


def encode_row(row: dict, category_maps: dict[str, list[str]]) -> np.ndarray:
    encoded = [1.0]
    encoded.extend(float(row[field]) for field in NUMERIC_FIELDS)

    for field in CATEGORICAL_FIELDS:
        value = row[field]
        categories = category_maps[field]
        encoded.extend(1.0 if category == value else 0.0 for category in categories)

    return np.array(encoded, dtype=float)


def prepare_training_data(rows: list[dict]) -> tuple[np.ndarray, np.ndarray, dict[str, list[str]], list[str]]:
    category_maps = extract_categories(rows)
    feature_order = build_feature_order(category_maps)

    x_matrix = np.vstack([encode_row(row, category_maps) for row in rows])
    y_vector = np.array([row[TARGET_FIELD] for row in rows], dtype=float)
    return x_matrix, y_vector, category_maps, feature_order


def train_model(csv_path: Path = DATA_PATH) -> tuple[CarPriceModel, dict[str, float]]:
    rows = load_dataset(csv_path)
    x_matrix, y_vector, category_maps, feature_order = prepare_training_data(rows)
    company_to_models = build_company_to_models(rows)

    # Closed-form least squares solution.
    weights = np.linalg.pinv(x_matrix) @ y_vector
    predictions = x_matrix @ weights

    mae = float(np.mean(np.abs(y_vector - predictions)))
    rmse = float(np.sqrt(np.mean((y_vector - predictions) ** 2)))
    r2_denom = float(np.sum((y_vector - np.mean(y_vector)) ** 2))
    r2 = 1.0 - (float(np.sum((y_vector - predictions) ** 2)) / r2_denom if r2_denom else 0.0)

    model = CarPriceModel(
        weights=weights,
        feature_order=feature_order,
        category_maps=category_maps,
        company_to_models=company_to_models,
    )
    metrics = {"mae": mae, "rmse": rmse, "r2": r2}
    return model, metrics


def save_model(model: CarPriceModel, model_path: Path = MODEL_PATH) -> None:
    model_path.parent.mkdir(parents=True, exist_ok=True)
    with model_path.open("wb") as file:
        pickle.dump(model, file)


def load_model(model_path: Path = MODEL_PATH) -> CarPriceModel:
    with model_path.open("rb") as file:
        return pickle.load(file)


def predict_price(model: CarPriceModel, car_data: dict) -> float:
    encoded = encode_row(car_data, model.category_maps)
    prediction = float(encoded @ model.weights)
    return max(prediction, 0.0)
