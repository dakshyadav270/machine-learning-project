from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk

from model_utils import MODEL_PATH, load_model, predict_price, train_model, save_model


def ensure_model():
    if Path(MODEL_PATH).exists():
        return load_model(MODEL_PATH)

    model, _ = train_model()
    save_model(model, MODEL_PATH)
    return model


class CarPricePredictorApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Car Price Predictor")
        self.root.geometry("720x640")
        self.root.resizable(False, False)

        self.model = ensure_model()

        self.company_var = tk.StringVar(value=self.model.category_maps["company_name"][0])
        initial_company = self.company_var.get()
        self.model_var = tk.StringVar(value=self.model.company_to_models[initial_company][0])
        self.original_price_var = tk.StringVar()
        self.kilometers_var = tk.StringVar()
        self.fuel_var = tk.StringVar(value=self.model.category_maps["fuel_type"][0])
        self.transmission_var = tk.StringVar(value=self.model.category_maps["transmission"][0])
        self.owner_var = tk.StringVar(value="1")
        self.age_var = tk.StringVar()
        self.result_var = tk.StringVar(value="Enter car details and click Predict Price.")

        self._build_ui()

    def _build_ui(self) -> None:
        style = ttk.Style()
        style.configure("Big.TLabel", font=("Arial", 15, "bold"))
        style.configure("Big.TButton", font=("Arial", 15, "bold"))

        title = ttk.Label(
            self.root,
            text="Used Car Price Predictor",
            font=("Arial", 24, "bold"),
        )
        title.pack(pady=16)

        form = ttk.Frame(self.root, padding=20)
        form.pack(fill="x")

        self.company_combo = self._add_dropdown(form, "Company Name", self.company_var, self.model.category_maps["company_name"], 0)
        self.model_combo = self._add_dropdown(form, "Car Model", self.model_var, self.model.company_to_models[self.company_var.get()], 1)
        self.company_combo.bind("<<ComboboxSelected>>", self.update_model_options)
        self._add_entry(form, "Original Price (lakh)", self.original_price_var, 2)
        self._add_entry(form, "Kilometers Driven", self.kilometers_var, 3)
        self._add_dropdown(form, "Fuel Type", self.fuel_var, self.model.category_maps["fuel_type"], 4)
        self._add_dropdown(form, "Transmission", self.transmission_var, self.model.category_maps["transmission"], 5)
        self._add_entry(form, "Owner Count", self.owner_var, 6)
        self._add_entry(form, "Car Age (years)", self.age_var, 7)

        button = ttk.Button(form, text="Predict Price", command=self.predict, style="Big.TButton")
        button.grid(row=8, column=0, columnspan=2, pady=22)

        result_box = ttk.Label(
            self.root,
            textvariable=self.result_var,
            wraplength=620,
            justify="center",
            font=("Arial", 16, "bold"),
            foreground="darkgreen",
        )
        result_box.pack(pady=10)

        hint = ttk.Label(
            self.root,
            text=f"Academic demo model | Year: {datetime.now().year}",
            font=("Arial", 12),
        )
        hint.pack(pady=6)

    def _add_entry(self, parent: ttk.Frame, label_text: str, variable: tk.StringVar, row: int) -> None:
        ttk.Label(parent, text=label_text, style="Big.TLabel").grid(row=row, column=0, sticky="w", padx=8, pady=10)
        ttk.Entry(parent, textvariable=variable, width=28, font=("Arial", 14)).grid(row=row, column=1, padx=8, pady=10)

    def _add_dropdown(self, parent: ttk.Frame, label_text: str, variable: tk.StringVar, values: list[str], row: int) -> ttk.Combobox:
        ttk.Label(parent, text=label_text, style="Big.TLabel").grid(row=row, column=0, sticky="w", padx=8, pady=10)
        combo = ttk.Combobox(parent, textvariable=variable, values=values, state="readonly", width=26)
        combo.configure(font=("Arial", 14))
        combo.grid(row=row, column=1, padx=8, pady=10)
        return combo

    def update_model_options(self, _event=None) -> None:
        selected_company = self.company_var.get().strip()
        available_models = self.model.company_to_models.get(selected_company, [])
        self.model_combo["values"] = available_models
        if available_models:
            self.model_var.set(available_models[0])

    def predict(self) -> None:
        try:
            car_data = {
                "company_name": self.company_var.get().strip(),
                "car_model": self.model_var.get().strip(),
                "original_price_lakh": float(self.original_price_var.get()),
                "kilometers_driven": float(self.kilometers_var.get()),
                "fuel_type": self.fuel_var.get().strip(),
                "transmission": self.transmission_var.get().strip(),
                "owner_count": float(self.owner_var.get()),
                "car_age_years": float(self.age_var.get()),
            }

            predicted_price = predict_price(self.model, car_data)
            self.result_var.set(f"Predicted resale price: {predicted_price:.2f} lakh rupees")
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter valid numeric values in all number fields.")


def main() -> None:
    root = tk.Tk()
    CarPricePredictorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
