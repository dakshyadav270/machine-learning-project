# Car Price Predictor

A mini machine learning project for diploma engineering students.

This project predicts the resale price of a used car from basic inputs:

- company name
- original price
- kilometers driven
- fuel type
- transmission
- owner count
- car age

## Project Files

- `data/car_data.csv` - sample training dataset
- `model_utils.py` - preprocessing, training, saving, and prediction logic
- `train_model.py` - trains the regression model
- `app.py` - simple Tkinter GUI for prediction
- `requirements.txt` - dependency list

## How It Works

The project uses a simple linear regression model built with NumPy. Categorical
fields like company, fuel, and transmission are converted into one-hot encoded
features before training.

## Run Steps

1. Install dependency:

```bash
pip install -r requirements.txt
```

2. Train the model:

```bash
python3 train_model.py
```

3. Start the GUI application:

```bash
python3 app.py
```

## Example Input

- company name: `Maruti`
- original price: `8.5`
- kilometers driven: `45000`
- fuel type: `Petrol`
- transmission: `Manual`
- owner count: `1`
- car age: `5`

## Output

Predicted resale price in lakh rupees.

## Notes

- Dataset values are sample values for academic mini-project use.
- Model accuracy depends on dataset quality and size.
- You can improve performance by adding more real car market data.
